var searchData=
[
  ['value',['VALUE',['../namespacestrange_1_1extensions_1_1injector_1_1api.html#aaf5414484d7eccb5c502984bd70549aeaecc2e9c313faddb07e7da223c1dc5c3f',1,'strange::extensions::injector::api']]]
];
