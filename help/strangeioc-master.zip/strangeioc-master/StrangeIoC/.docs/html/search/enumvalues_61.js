var searchData=
[
  ['automatic',['AUTOMATIC',['../namespacestrange_1_1extensions_1_1context_1_1api.html#a6e67a548377c1491bddc3a81c0f312c5a008f6cdd0c190839e9885cf9f9e2a652',1,'strange::extensions::context::api']]],
  ['awake',['AWAKE',['../namespacestrange_1_1extensions_1_1mediation_1_1api.html#ae5a81bb1edf9fca1d2aca9f4fada72a8afca549f3541c801906abc34b45e8953e',1,'strange::extensions::mediation::api']]]
];
