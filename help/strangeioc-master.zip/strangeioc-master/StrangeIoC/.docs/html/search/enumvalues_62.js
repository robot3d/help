var searchData=
[
  ['bad_5fconstructor',['BAD_CONSTRUCTOR',['../namespacestrange_1_1extensions_1_1command_1_1api.html#a27c9226cc8d55624f3294319d48879e3a4ca656dfba09ff902c42fee01c7c8405',1,'strange::extensions::command::api']]]
];
