var searchData=
[
  ['eventcallbacktype',['EventCallbackType',['../namespacestrange_1_1extensions_1_1dispatcher_1_1eventdispatcher_1_1api.html#a7135cff6e8e84b74fb1aee88c8f5af4c',1,'strange::extensions::dispatcher::eventdispatcher::api']]],
  ['eventdispatcherexceptiontype',['EventDispatcherExceptionType',['../namespacestrange_1_1extensions_1_1dispatcher_1_1eventdispatcher_1_1api.html#ac82e4192fcc43ba5e64f0469a3c7c06d',1,'strange::extensions::dispatcher::eventdispatcher::api']]]
];
