var searchData=
[
  ['sequencerexceptiontype',['SequencerExceptionType',['../namespacestrange_1_1extensions_1_1sequencer_1_1api.html#aeddaacdea22f90d94ab298d24cbce41b',1,'strange::extensions::sequencer::api']]],
  ['signalexceptiontype',['SignalExceptionType',['../namespacestrange_1_1extensions_1_1signal_1_1api.html#a1303547618565f5ed4dea0f25f27975d',1,'strange::extensions::signal::api']]]
];
