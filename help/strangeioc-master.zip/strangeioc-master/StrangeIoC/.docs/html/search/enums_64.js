var searchData=
[
  ['dispatcherexceptiontype',['DispatcherExceptionType',['../namespacestrange_1_1extensions_1_1dispatcher_1_1api.html#a03ba459ad62cc042c88405d9419eb4c6',1,'strange::extensions::dispatcher::api']]]
];
