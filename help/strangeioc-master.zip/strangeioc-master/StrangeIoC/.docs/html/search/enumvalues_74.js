var searchData=
[
  ['target_5finvocation',['TARGET_INVOCATION',['../namespacestrange_1_1extensions_1_1dispatcher_1_1eventdispatcher_1_1api.html#ac82e4192fcc43ba5e64f0469a3c7c06da830201fce8c6a7f553432649727cd2e1',1,'strange::extensions::dispatcher::eventdispatcher::api']]],
  ['type_5fmismatch',['TYPE_MISMATCH',['../namespacestrange_1_1extensions_1_1pool_1_1api.html#a93ccdd4d6e731ba8a31a774428edec32a2f93918ef99e03b7b8e7230b2a28fb52',1,'strange::extensions::pool::api']]]
];
