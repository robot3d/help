var searchData=
[
  ['warning',['WARNING',['../namespacestrange_1_1extensions_1_1pool_1_1api.html#afb1f831222aa94de2fcb447a88146ad0a059e9861e0400dfbe05c98a841f3f96b',1,'strange::extensions::pool::api']]]
];
