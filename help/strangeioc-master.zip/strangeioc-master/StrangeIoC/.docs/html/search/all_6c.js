var searchData=
[
  ['launch',['Launch',['../interfacestrange_1_1extensions_1_1context_1_1api_1_1_i_context.html#a2990b107f219e79a1ed87695732c6533',1,'strange.extensions.context.api.IContext.Launch()'],['../classstrange_1_1extensions_1_1context_1_1impl_1_1_context.html#a02c426aaa7b4cdae6bc1be3060b67dce',1,'strange.extensions.context.impl.Context.Launch()'],['../classstrange_1_1extensions_1_1context_1_1impl_1_1_m_v_c_s_context.html#a70e1400cfb5a71447080acdf79ca93f9',1,'strange.extensions.context.impl.MVCSContext.Launch()']]]
];
