var searchData=
[
  ['setter_5fname_5fmismatch',['SETTER_NAME_MISMATCH',['../namespacestrange_1_1extensions_1_1injector_1_1api.html#a465caee64cba80e952ad7dd9a050e6c3aa2bdd50d3a2f2f510f0209f648f0c0b6',1,'strange::extensions::injector::api']]],
  ['single_5fcontext',['SINGLE_CONTEXT',['../namespacestrange_1_1extensions_1_1injector_1_1api.html#ab0f6d151014ae36671ff9f98e77fbf58a5efb0d7efb9ed38fdfc18f50c75570a4',1,'strange::extensions::injector::api']]],
  ['singleton',['SINGLETON',['../namespacestrange_1_1extensions_1_1injector_1_1api.html#aaf5414484d7eccb5c502984bd70549aeaecf2a6aabcb0538532ba2a7d0d281557',1,'strange::extensions::injector::api']]],
  ['start',['START',['../namespacestrange_1_1extensions_1_1context_1_1api.html#a92a831a11b0bd5ee051b35745b33791aab078ffd28db767c502ac367053f6e0ac',1,'strange::extensions::context::api']]]
];
