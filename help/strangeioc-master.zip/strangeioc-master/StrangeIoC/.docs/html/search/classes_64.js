var searchData=
[
  ['deconstruct',['Deconstruct',['../class_deconstruct.html',1,'']]],
  ['dispatcherexception',['DispatcherException',['../classstrange_1_1extensions_1_1dispatcher_1_1impl_1_1_dispatcher_exception.html',1,'strange::extensions::dispatcher::impl']]]
];
