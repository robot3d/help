var searchData=
[
  ['pool',['POOL',['../namespacestrange_1_1framework_1_1api.html#a9819c5ab6d03a2cbce2d3dddf5264e42a3225d08271bdcb752dd48b2a836c8998',1,'strange::framework::api']]]
];
