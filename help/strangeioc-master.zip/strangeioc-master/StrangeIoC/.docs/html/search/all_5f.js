var searchData=
[
  ['_5fcrosscontextdispatcher',['_crossContextDispatcher',['../classstrange_1_1extensions_1_1context_1_1impl_1_1_cross_context.html#a00c68512ad80d15236954614f223820e',1,'strange::extensions::context::impl::CrossContext']]]
];
