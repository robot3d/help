# CommandCenter

This extension is used by command based extensions such as the Event Command Map.

It is not intended to be used directly.
